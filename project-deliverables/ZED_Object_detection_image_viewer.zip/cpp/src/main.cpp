///////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2024, STEREOLABS.
//
// All rights reserved.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////

/*****************************************************************************************
 ** This sample demonstrates how to detect objects and retrieve their 3D position       **
 **         with the ZED SDK and display the result in an OpenGL window.                **
 *****************************************************************************************/

// ZED includes
#include <sl/Camera.hpp>

// Sample includes
#include "GLViewer.hpp"
#include "FileReader.hpp"


// Using std and sl namespaces
using namespace std;
using namespace sl;

void print(string msg_prefix, ERROR_CODE err_code = ERROR_CODE::SUCCESS, string msg_suffix = "");
void parseArgs(int argc, char **argv, InitParameters& param, string& input_file, string& output_file);

// Function to save the centroids to a file
void saveCentroidsToFile(const std::vector<TimeCentroid>& centroids, const string& filename) {
    ofstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to open file for saving centroids." << endl;
        return;
    }
    file << "timestamp,x,y,z" << endl;
    cout << centroids.size() << endl;
    for (const auto& data : centroids) {
        auto centroid = data.second;
        file << data.first << "," << centroid.x << "," << centroid.y << "," << centroid.z << endl;
    }

    file.close();
    cout << "Centroids saved to " << filename << endl;
}

std::vector<sl::uint2> cvt(const BBox& bbox_in) {
    std::vector<sl::uint2> bbox_out(4);
    bbox_out[0] = sl::uint2(bbox_in.x1, bbox_in.y1);
    bbox_out[1] = sl::uint2(bbox_in.x2, bbox_in.y1);
    bbox_out[2] = sl::uint2(bbox_in.x2, bbox_in.y2);
    bbox_out[3] = sl::uint2(bbox_in.x1, bbox_in.y2);
    return bbox_out;
}

int main(int argc, char **argv) {

#ifdef _SL_JETSON_
    const bool isJetson = true;
#else
    const bool isJetson = false;
#endif 

    // Create ZED objects
    Camera zed;
    InitParameters init_parameters;
    string input_file;
    string output_file;
    init_parameters.depth_mode = DEPTH_MODE::ULTRA;
    init_parameters.coordinate_system = COORDINATE_SYSTEM::RIGHT_HANDED_Y_UP;
    init_parameters.coordinate_units = UNIT::METER;
    parseArgs(argc, argv, init_parameters, input_file, output_file);
    
    std::map<int, TimeBBox> boxes;
    FileReader reader(input_file);
    if (reader.readBoxFile()) {
        boxes = reader.getBoundingBoxMap();
    }
    else {
        std::cerr << "Failed to read file." << std::endl;
    }

    // Open the camera
    auto returned_state = zed.open(init_parameters);
    if (returned_state != ERROR_CODE::SUCCESS) {
        print("Open Camera", returned_state, "\nExit program.");
        zed.close();
        return EXIT_FAILURE;
    }

    // Enable Positional tracking (mandatory for object detection)
    PositionalTrackingParameters positional_tracking_parameters;
    //If the camera is static, uncomment the following line to have better performances.
    //positional_tracking_parameters.set_as_static = true;
    returned_state = zed.enablePositionalTracking(positional_tracking_parameters);
    if (returned_state != ERROR_CODE::SUCCESS) {
        print("enable Positional Tracking", returned_state, "\nExit program.");
        zed.close();
        return EXIT_FAILURE;
    }

    // Enable the Objects detection module
    ObjectDetectionParameters obj_det_params;
    obj_det_params.enable_tracking = false;
    obj_det_params.detection_model = isJetson ? OBJECT_DETECTION_MODEL::MULTI_CLASS_BOX_FAST : OBJECT_DETECTION_MODEL::CUSTOM_BOX_OBJECTS;

    returned_state = zed.enableObjectDetection(obj_det_params);
    if (returned_state != ERROR_CODE::SUCCESS) {
        print("enable Object Detection", returned_state, "\nExit program.");
        zed.close();
        return EXIT_FAILURE;
    }

    auto camera_info = zed.getCameraInformation().camera_configuration;
    // Create OpenGL Viewer
    GLViewer viewer;
    viewer.init(argc, argv, camera_info.calibration_parameters.left_cam, obj_det_params.enable_tracking = false);

    // Configure object detection runtime parameters
    ObjectDetectionRuntimeParameters objectTracker_parameters_rt;

    // Create ZED Objects filled in the main loop
    Objects objects;
    Mat image;

    ObjectData obj;
    float inc = 0.01;
    obj.bounding_box = { {-1.61882, 0.936091, -2.39861}, {-1.61893, 0.930859, -2.89859}, {-1.11904, 0.920544, -2.89859}, {-1.11893, 0.925776, -2.39861},
                         {-1.6475, -0.453454, -2.38407}, {-1.6476, -0.458686, -2.88404}, {-1.14771, -0.469001, -2.88404}, {-1.1476, -0.463769, -2.38407} };
    obj.bounding_box = { {0.61882, 0.936091, -2.39861}, {0.61893, 0.930859, -2.89859}, {1.51904, 0.920544, -2.89859}, {1.51893, 0.925776, -2.39861},
                         {0.6475, -0.453454, -2.38407}, {0.6476, -0.458686, -2.88404}, {1.54771, -0.469001, -2.88404}, {1.5476, -0.463769, -2.38407} };
    obj.label = OBJECT_CLASS::LAST;
    obj.id = 1;
    obj.tracking_state = OBJECT_TRACKING_STATE::OK;
    // obj.position = { 5, 5, 5 };
    //objects.object_list.push_back(obj);

    std::vector<BBoxInfo> detections;
    detections.push_back({ { 100, 100, 600, 600 }, 1875, 0.8 });
    std::vector<sl::CustomBoxObjectData> objects_in;
    // The "detections" variable contains your custom 2D detections
    for (auto& it : detections) {
        sl::CustomBoxObjectData tmp;
        // Fill the detections into the correct SDK format
        tmp.unique_object_id = sl::generate_unique_id();
        tmp.probability = it.prob;
        tmp.label = (int)it.label;
        tmp.bounding_box_2d = cvt(it.box);
        tmp.is_grounded = true; // objects are moving on the floor plane and tracked in 2D only
        objects_in.push_back(tmp);
    }

    std::vector<TimeCentroid> centroids;
    
    // Main Loop
    int frame = 0;
    while (viewer.isAvailable() && zed.grab() == ERROR_CODE::SUCCESS) {
        // Retrieve left image for display
        zed.retrieveImage(image, VIEW::LEFT, MEM::GPU);

        // objects.object_list[0].bounding_box = boxes[frame];
        if (boxes.find(frame) != boxes.end()) {
            auto data = boxes[frame];
            objects_in[0].bounding_box_2d = cvt(data.second);
            cout << "Updated bbox\n";

            zed.ingestCustomBoxObjects(objects_in);
            zed.retrieveObjects(objects, objectTracker_parameters_rt);


            cout << "[HYUNSOO] After: " << objects.object_list.size() << endl;
            centroids.push_back(TimeCentroid(data.first, objects.object_list[0].position));
        }
        //Update rendering, image with detected object overlay
        viewer.updateView(image, objects);
        
        frame++;
        cout << frame << endl;
    }

    // Release objects
    image.free();
    objects.object_list.clear();

    // After processing all detections, save the centroids to a file
    saveCentroidsToFile(centroids, output_file);

    // Disable modules
    zed.disableObjectDetection();
    zed.disablePositionalTracking();
    zed.close();
    return EXIT_SUCCESS;
}



void parseArgs(int argc, char **argv, InitParameters& param, string& input_file, string& output_file) {
    if (argc != 4) {
        cout << "Usage: <program> <.svo file> <full_coords.json file> <output_coords.json file>" << endl;
        exit(EXIT_FAILURE);
    }
    input_file = argv[2];
    output_file = argv[3];
    
    if (argc > 0 && string(argv[1]).find(".svo") != string::npos) {
        // SVO input mode
        param.input.setFromSVOFile(argv[1]);
        cout << "[Sample] Using SVO File input: " << argv[1] << endl;
    }
    else {
        cout << "[Error] Invalid .svo file format" << endl;
        exit(EXIT_FAILURE);
    }
}

void print(string msg_prefix, ERROR_CODE err_code, string msg_suffix) {
    cout << "[Sample]";
    if (err_code != ERROR_CODE::SUCCESS)
        cout << "[Error]";
    cout << " " << msg_prefix << " ";
    if (err_code != ERROR_CODE::SUCCESS) {
        cout << " | " << toString(err_code) << " : ";
        cout << toVerbose(err_code);
    }
    if (!msg_suffix.empty())
        cout << " " << msg_suffix;
    cout << endl;
}
