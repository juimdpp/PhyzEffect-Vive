﻿#include "FileReader.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <sl/Camera.hpp>
#include <nlohmann/json.hpp>
#include <regex>

FileReader::FileReader(const std::string& filename) : filename(filename) {}

bool FileReader::readBoxFile() {
    std::cout << filename << std::endl;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Could not open the file: " << filename << std::endl;
        return false;
    }

    try {
        json data = json::parse(file);

        int frameCnt = 0;
        for (auto& element : data.items()) {
            auto value = element.value();   // bbox
            auto key = stoll(element.key()); // timestamp

            if (value.size() > 0) {
                boundingBoxMap[frameCnt++] = TimeBBox(key, BBox({ value[0], value[1], value[2], value[3] }));
            }

        }
    }
    catch (const std::exception& e) {
        std::cerr << "Error parsing JSON: " << e.what() << std::endl;
        return false;
    }
}

bool FileReader::readFile() {
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Could not open the file: " << filename << std::endl;
        return false;
    }

    std::string line;
    std::vector<sl::float3> currentBoundingBox;
    int cnt = 0;

    try {
        // Parse the JSON file
        json data = json::parse(file);
        

        // Iterate through each frame (key in JSON)
        for (auto& element : data.items()) {
            auto value = element.value();
            auto key = stoi(element.key());

            // For each bounding box data in the frame, create a Vector3 object
            for (const auto& point : value) {

                if (point.size() != 3) {
                    std::cerr << "Invalid bounding box point data for " << key << std::endl;
                    continue;
                }

                // Add each point (x, y, z) to the bounding box vector
                float x = point[0];
                float y = point[1];
                float z = point[2];
                currentBoundingBox.push_back(sl::float3(x, y, z));
            }

            // Store the ObjectData for the current frame
            boundingBoxes[key] = currentBoundingBox;
            currentBoundingBox.clear();
        }

    }
    catch (const std::exception& e) {
        std::cerr << "Error parsing JSON: " << e.what() << std::endl;
        return false;
    }


    file.close();
    return true;
}

std::map<int, std::vector<sl::float3>> FileReader::getBoundingBoxes() const {
    return boundingBoxes;
}

std::map<int, TimeBBox> FileReader::getBoundingBoxMap() const {
    return boundingBoxMap;
}
