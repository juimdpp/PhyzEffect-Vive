﻿
struct BBox {
    float x1, y1, x2, y2;
};

struct BBoxInfo {
    BBox box;
    int label;
    float prob;
};

typedef std::pair<long long, BBox> TimeBBox;

typedef std::pair<long long, sl::float3 > TimeCentroid;