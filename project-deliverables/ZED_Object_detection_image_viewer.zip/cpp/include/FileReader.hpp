﻿#ifndef FILEREADER_H
#define FILEREADER_H

#include <string>
#include <vector>
#include <sl/Camera.hpp>
#include <nlohmann/json.hpp>
#include "utils.hpp"

using json = nlohmann::json;

class FileReader {
public:
    FileReader(const std::string& filename);
    bool readFile();
    bool readBoxFile();
    std::map<int, std::vector<sl::float3>> getBoundingBoxes() const;
    std::map<int, TimeBBox> getBoundingBoxMap() const;

private:
    std::string filename;
    std::map<int, std::vector<sl::float3>> boundingBoxes;  // Stores the parsed points
    std::map<int, TimeBBox> boundingBoxMap; // For each frame, there is a single bounding box
};

#endif // FILEREADER_H
